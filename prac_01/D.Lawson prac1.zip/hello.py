
print ('Hello World')
