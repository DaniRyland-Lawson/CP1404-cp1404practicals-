
for i in range(1, 21, 2):
    print(i, end=' ')
print()

for i in range(0, 101, 10):
    print(i, end=' ')
print()

for i in range(20, 0, -1):
    print(i, end=' ')
print()

i = int(input("Please enter a number between 1-10: "))
for i in range(0, 11, +1):
    print("*", end=' ')
print('*')

# I have struggled with printing stars.
# It will print but not from the number the user gives.